"""
Variável: é um dado que salvamos na memória do computador
ex.:
nome = 'Ace'
sobrenome = 'Snow'
print(nome + ' ' + sobrenome) = Ace Snow

print(nome + ' ' + sobrenome, type(nome), type(sobrenome), bool(nome))
- chamei nome, sobrenome, pedi o tipo de ambos e transformei nome em booleano

Variáveis não podem começar com números
"""
print('Conteúdo sobre Variável')
print('Atenção: Abrir o arquivo e ler a documentação do código!')
nome = 'Snow'
idade = 21
altura = 1.72
maioridade = idade > 18
peso = 50
cor = 'branco'
imc = peso/altura**2
abaixo_peso = imc < 24.9
print('Nome:', nome)
print('Idade:', idade)
print('Altura:', altura, str(altura))
print('Maioridade:', maioridade)
print('Peso:', peso, 'kg')
print('Cor:', cor)
print(nome, 'tem', idade, 'anos de idade e seu Índice de Massa Corporal (IMC) é de', imc)
print('O IMC do', nome, 'está abaixo do peso normal?', abaixo_peso)

