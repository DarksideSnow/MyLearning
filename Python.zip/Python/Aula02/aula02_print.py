"""
Função *Print*
A função PRINT serve para mostrar algo na tela depois de receber um argumento, bem no sentido literal da palavra
*Adicional:
Ao abrir "print()" estamos nos referindo de uma função ou uma classe no caso do python

Esta função pode reber mais de um argumento em um só parâmetro
Exemplo:
print('argumento 01', 'argumento 02', 'argumento 03'); A separação é feita automaticamente após a adição das vírgulas

O python diferencia letras minúsculas de letras maiúsculas

"""

"""
Lista de Argumentos Nomeados:

- sep='' (separa o que está escrito dentro da função print) / (separador)
exemplo:
print('Quinta', 'Feira', sep='-')
Quinta-Feira

- end='' (retira o padrão da quebra de linha juntando duas linhas PRINT em uma) / (finalizador)
exemplo:
print('Quinta','Feira', sep='-', end='/')
print('Sexta', 'Feira', sep='-', end='')
Quinta-Feira/Sexta-Feira
"""
print('Conteúdo sobre a função PRINT')
print('Atenção: Abrir o arquivo e ler a documentação do código!')
print('Exemplo:')
print('abcdef')  # "abcdef" é um argumento da função print
print('Quinta','Feira', sep='-')  # Argumento Nomeado 'sep'

print('Quinta','Feira', sep='-', end='/')  # Argumento Nomeado 'end'
print('Sexta', 'Feira', sep='-')  # Argumento Nomeado 'end'

# Exercício do professor
print('Exemplo de gerador de CPF:')  # Mostrado em aula pelo professor e criado por mim
print(192, 176, '027', sep='.', end='-')
# Ao incluir números e um deles for zero colocar a aspa '027'
# caso não adicione, ele retornará um erro sobre o decimal 0
print(15)

# Teste feito na plataforma
print('estou', 'aprendendo', 'python', sep='-', end='')
print('isso é muito','legal', sep='-',end='')