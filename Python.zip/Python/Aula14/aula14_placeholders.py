"""
Pass e Ellipsis como placeholders
- Muitas linguagens de programação utilizam "{}" (chaves) como blocos, mas em Python não definimos blocos de códigos.
ex.:
valor = True
if valor:
    print("You're welcome")
else:
    print("You're not welcome!")
    ________________________________
valor = True
if valor:
    pass
else:
    print("You're not welcome!")    -- caso seja true retornará um "bloco" vazio
                                    -- caso seja false retornará o "bloco" else


A função Pass é utilizada como placeholder, significa que algum desenvolvedor iria digitar algo ali.
Ellipsis (...) nesse caso funcionaria igual ao 'pass'
"""
valor = True
if valor:
    ...  # Caso if = true retornará 'boas vindas' posteriormente
else:
    print("You're not welcome!")