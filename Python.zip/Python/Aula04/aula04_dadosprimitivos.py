"""
Tipos de Dados "Primitivos"
str: String - é uma cadeia de caractéres, um simples texto;
int: Inteiro - são números inteiros tanto positivos como negativos;
(ex.: 1234, 1000, 4000, 500 / 0 / -100, -200, -400, -4000 etc)
float: Número real/Ponto Flutuante - são números "quebrados", aqueles que possuem decimal;
(ex.: 0.10, 0.4, 0.24, 10.04 / 0.2 / -10.1, -2.9, -40.20, -4.4 etc)
bool: Valor Booleano/Lógico - existem apenas dois valores sendo true e false, o interpretador retorna se o cálculo é
verdadeiro ou falso.

A função "type" retorna a classe do código para o usuário;
Exemplo:
print(type('Olá mundo')) - classe str = string

A função "bool" retorna o valor do código para o usuário;
Exemplo:
print(bool('')) - false

"Type Casting" - É possível converter um tipo para outro ao utilizar um dos dados primitivos;
Exemplo:
print('Mr.Snow', type('Mr.Snow'), bool('Mr.Snow'))
"""

print('Conteúdo sobre Dados Primitivos')
print('Atenção: Abrir o arquivo e ler a documentação do código!')
print(type('Olá universo'))  # exemplo da função "type"
# retorna <class 'str'>
print('Exemplo da função "Type":')
print('"O universo canta para mim"', type('"O universo canta para mim"'))  # <class'str'>
print(1234, type(1234))  # <class 'int'>
print(0.40, type(0.40))  # <class 'float'>
print(40==40, type(40==40))  # <class 'bool'>
print('Exemplo da função "Bool":')
print(bool(''))  # retorna "false" pois está vazio
print(bool(0))  # retorna "false" pois é neutro
print(bool('Oi'))  # retorna "true" pois possui caractéres
print(bool(4))  # retorna "true" pois possui número impar ou par
print('Exemplo de "Type Casting":')
print('Mr.Snow', type('Mr.Snow'), bool('Mr.Snow'))  # retona a classe e o valor lógico do código (true)
print(0, type(0), bool(0))  # retona a classe e o valor lógico do código (false)
print(4, type(4), str(4))  # retona a classe e o tranforma em string ('4')
print(4, type(4), float(4))  # retona a classe e o tranforma em flutuante (4.0)
print(4.6, type(4.6), int(4.6))  # retona a classe e o tranforma em inteiro (4)
