print('Conteúdo sobre comentário')
print('Atenção: Abrir o arquivo e ler a documentação do código!')
print('A cerquilha (#) inicia um comentário no código. Isso não afeta o código pois é um comentário')
print('O comentário serve para localizar algum outro desenvolvedor a entender o funcionamento e finalidade do código')
print('Existe outro tipo de comentário que é a aspa dupla ("). Quando digitada sequencialmente por três vezes (""") ela se torna um comentário')
print('A aspa dupla (""") é utilizada na verdade como uma documentação do código, ou seja, mostrar para outro desenvolvedor a funcionalidade do código')
print('###############')
print('Objetivo')
# O real objetivo é criar um portfólio para o GitHub
print('Estudar Python')
# Estudar a fundo tudo o que o curso propõe
print('Dominar algum comando')
# Dominar qualquer coisa dessa linguagem (plotagem, sql, automação etc)
print('Publicar um primeiro projeto no Ghub')
# Publicar qualquer código sobre python no Github a fim de concluir uma parte do objetivo
print('Manter o mesmo empenho inicial')