"""
Formatando Valores com Modificadores

":s": Texto (strings)
":d": floateiros (float)
":f": Números de ponto flutuante (float)
":.(número)f": Quantidade de casas decimais (float)

":(caractere)(> / < / ^)(quantidade)(tipo -s, d ou f)"

">": Direita
"<": Esquerda
"^": Centro
"""
print('Correia Dentada (R$67)')
print('Tensor da Dentada (R$78)')
print('Rolo Guia (R$123)')
print('Engrenagem do Virabrequim (R$78)')
x = input('Valor do produto: ')
y = input('Valor do produto: ')
if x.isnumeric() and y.isnumeric():
    x = int(x)
    y = int(y)
    adict = x + y
    print(f'{adict:$>4}')
else:
    print('Informe o valor correto!')
input()
