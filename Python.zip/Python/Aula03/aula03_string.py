"""
String = str
O string é uma cadeia de caractéres;
É um interpretador de textos dentro das aspas na função "print";
O Python não consegue interpretar textos sem estar identificado como "string";
Números podem ou não estar como "string";

O Python é uma linguagem de típagem dinâmica e entende o "string" em aspas
-Exemplo:
print('Olá mundo') / print("Olá mundo") exibirá "Olá mundo" na tela quando rodar o código;
print(Olá mundo) retornará um erro pois o python não conseguiu identificar a função.

Para usar aspas dentro da função "print" é só trocar as aspas, se abriu a string com aspa única o texto deverá ter aspa
dupla ou o contrário;
Existe caractéres de escape para "corrigir" essas aspas, porém suja o código, atrapalha fuções e não é recomendado;
Exemplo de função:
print(r'Esse é o \n \'meu\' universo')
\n = utilizado para quebrar o texto para outra linha
r (raw) = utilizado para identificar que o que está na função print é apenas texto e não deverá ser executado.


"""
print('Conteúdo sobre String (str)')
print('Atenção: Abrir o arquivo e ler a documentação do código!')
print('Olá mundo')
# pode ser usado com aspa única
print("Olá universo")
# ou com aspa dupla
print("Esse é o \"meu\" mundo")
# Exemplo do caractére de escape
print('Esse é o \'meu\' mundo')
# Exemplo do caractére de escape