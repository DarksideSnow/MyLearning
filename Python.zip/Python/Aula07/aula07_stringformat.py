"""
Introdução à Formatação de Strings
A letra "f" é usada para formatar uma string  facilitando o desenvolver
ex.:
nome = 'Snow'
idade = 21
altura = 1.72
maioridade = idade > 18
peso = 50
cor = 'branco'
imc = peso/altura**2
abaixo_peso = imc < 24.9

print(f'{nome} tem {idade} anos de idade e seu Índice de Massa Corporal (IMC) é de {imc}')
print(f'O IMC do {nome} está abaixo do peso normal? {abaixo_peso}')
--------------------------------------------------------------------
Também é possível definir a quantidade de casas decimais de um 'float'
ex.:
print(f'{nome} tem {idade} anos de idade e seu Índice de Massa Corporal (IMC) é de {imc:.4f}')
--------------------------------------------------------------------
Existem um outro meio de formatar a string, porém polui o código
ex.:
print('{} tem {} anos de idade e seu índice de Massa Corporal (IMC) é de {}'.format(nome, idade, imc:.4f))
"""
print('Conteúdo sobre Formatação de Strings')
print('Atenção: Abrir o arquivo e ler a documentação do código!')
print('Exemplo:')
nome = 'Snow'
idade = 21
altura = 1.72
maioridade = idade > 18
peso = 50
cor = 'branco'
imc = peso/altura**2
abaixo_peso = imc < 24.9
print(f'{nome} tem {idade} anos de idade e seu Índice de Massa Corporal (IMC) é de {imc:.4f}')
print(f'O IMC do {nome} está abaixo do peso normal? {abaixo_peso}')
print('----')
print('Segundo tipo de formatação:')
print('{} tem {} anos de idade e seu índice de Massa Corporal (IMC) é de {:.4f}'.format(nome, idade, imc))