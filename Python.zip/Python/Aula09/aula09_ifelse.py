"""
Condições
if: "E se" caso seja em uma condição verdadeira executará uma açõa determinada no bloco
elif: "Se não" caso seja uma condição falsa executará outra ação determinada no bloco
else: Sigla para 'else_if' assim como as outras serve para comparar e xecutar uma ação

Aula (If, Elif, Else)
if True:
    print('É verdade esse bilhete')
elif False:
    print('Confia não cria')
elif True:
    print('Confia!')
else:
    print('MENTIRA')
"""
print('Teste + Conteúdo sobre If, Elif e Else:')
print('Atenção: Abrir o arquivo e ler a documentação do código!')
print('Teste realizado com um código feito anteriormente')
nome = 'Snow'
idade = 22
altura = 1.72
peso = 52.4
ano = 2022
nascimento = ano - idade
imc = peso/altura**2

print(f'{nome} tem {idade} anos de idade, tem {altura} e pesa {peso}kg;')
print(f'O IMC (Índice de Massa Corporal) do(a) {nome} é de {imc:.4f};')
if imc >= 24.9:
    print(f'O(A) {nome} está com o IMC ideal? r: Não')
elif imc <= 18.4:
    print(f'O(A) {nome} está com o IMC ideal? r: Não')
else:
    print(f'O(A) {nome} está com o IMC ideal? r: Sim')
if idade >= 18:
    print(f'O(A) {nome} possui maioridade? r: Sim')
else:
    print(f'O(A) {nome} possui maioridade? r: Não')
print(f'Qual o ano de nascimento do(a) {nome}? r: {nascimento}')
