"""
Operadores Lógicos:
Serve para comparar variáveis numa mesma linha e sem uma condição específica

and:
'e' realiza duas comparações de variáveis na mesma linha e retorna valor booleano
Só será verdadeiro quando as duas comparações estiverem corretas
ex.:

idade = input('Informe sua idade: ')
idade_menor = 18
idade_maior = 65

if int(idade) >= idade_menor and int(idade) <= idade_maior:
    print('Pode pedir empréstimo')
else:
    print('não pode pegar empréstimo')


or:
'ou' também realiza comparações entre valores, porém apenas um dos valores precisa ser 'true' para
 o todo retornar 'true', retornando apenas a condição de if.

not:
'não' precisa de apenas uma expressão, chama-se operador de inversão porque ele inverte o valor
ex.:
x = 4
y = 8
if not x < y:
    print('x é maior que y\n')
else:
    print('y é menor que x\n')

in:
'em' se algum valor estiver expresso em uma variável, retorna um valor 'true'
ex.:
name = 'Wallace'
if 'll' in name:
     print('Wallace com 2 "L"')

not in:
"não em" semelhante ao 'not' visto anteriormente

"""
print('Conteúdo sobre Operador Relacional: \n Atenção: Abrir o arquivo e ler a documentação do código!\n')
print('Exemplo de "and":\n')
idade = input('Informe sua idade: ')
idade_menor = 18
idade_maior = 65

if int(idade) >= idade_menor and int(idade) <= idade_maior:
    print('Pode pedir empréstimo')
else:
    print('não pode pegar empréstimo\n')

print('Exemplo de "or":\n')
idade = input('Informe sua idade: ')
idade_menor = 18
idade_maior = 65

if int(idade) >= idade_menor or int(idade) <= idade_maior:
    print('Pode pedir empréstimo\n')
else:
    print('não pode pegar empréstimo\n')

print('Exemplo de "not":\n')
x = 4
y = 8
if not x < y:
    print('x é maior que y\n')
else:
    print('y é menor que x\n')

print('Exemplo de "in":\n')
name = 'Wallace'
if 'll' in name:
     print('Wallace com 2 "L"\n')

print('Exemplo de "not in":\n')
name = 'Wallace'
if 'll' not in name:
     print('Wallace com 2 "l"\n')
else:
    print('Não existe 2 "l" aqui.')
