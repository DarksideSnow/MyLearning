"""
* Criar variáveis para o nome (str), idade (int);
altura (float) e peso (float) de uma pessoa
* Criar variável com o ano atual
* Obter o ano de nascimento da pessoa (baseado na idade e no ano atual)
* Obter o IMC da pessoa com 4 casas decimais (peso e altura da pessoa elevado ao quadrado)
* Exibir um texto com todos os valores na tela usando F-Strings (com as chaves)

*Extra (_snow): dizer se o IMC é ideal e se a pessoa possui maioridade
"""
nome = 'Snow'
idade = 22
altura = 1.72
peso = 52.4
ano = 2022
nascimento = ano - idade
imc = peso/altura**2
maioridade = 18 < idade
imc_abaixo = imc < 18.4
imc_acima = imc > 24.9
imc_normal = imc_abaixo < imc_acima

print(f'{nome} tem {idade} anos de idade, tem {altura} e pesa {peso}kg;')
print(f'O IMC (Índice de Massa Corporal) do(a) {nome} é de {imc:.4f};')
print(f'O(A) {nome} está com o IMC ideal? r: Normal? {imc_normal} / Abaixo? {imc_abaixo} / Acima? {imc_acima}')
print(f'O(A) {nome} possui maioridade? r: {maioridade}')
print(f'Qual o ano de nascimento do(a) {nome}? r: {nascimento}')
