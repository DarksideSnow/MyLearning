print('Meu teste')
user = input('Informe seu nome: ')
hour = input('Informe a hora (00 - 23): ')

if hour.isnumeric:
    hour = int(hour)

    if hour < 0 or hour > 23:
        print('Informe um horário (UTC-3) de 00 (horas) à 23 (horas)')
    else:
        if hour <= 5:
            print(f'Boa madrugada, {user}!')
        elif hour <= 11:
            print(f'Boa manhã, {user}!')
        elif hour <= 17:
            print(f'Boa tarde, {user}!')
        elif hour <= 23:
            print(f'Boa noite, {user}!')
else:
    print('Informe um horário (UTC-3) de 00 (horas) à 23 (horas)')