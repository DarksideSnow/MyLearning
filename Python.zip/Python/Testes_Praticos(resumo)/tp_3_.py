print('Meu teste')
primary_name = input('Informe o seu primeiro nome: ')

if primary_name.isalpha():
    user_1 = len(primary_name)
    if user_1 <= 4:
        print('O seu nome está abaixo ou muito abaixo da média!')
    elif user_1 <= 6:
        print('O seu nome está na média.')
    else:
        print('Seu nome está acima ou muito acima da média! ')

else:
    print('Digite apenas letras!')
