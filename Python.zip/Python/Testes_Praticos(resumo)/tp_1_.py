print('Meu teste')
inteiro = input('Digite um número inteiro!: ')

if inteiro.isnumeric():
    inteiro = int(inteiro)

    if inteiro % 2 == 0:
        print('Seu número é par!')
    else:
        print('Seu número é ímpar')
else:
    print('Seu número não é um inteiro')
