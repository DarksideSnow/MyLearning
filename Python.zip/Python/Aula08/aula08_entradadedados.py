"""
Entrada de Dados

Input = é uma função de entrada de dados
ex.: nome = input('Qual o seu nome?')
A variável recebe o valor no 'input' e exibe em string na função 'print'
"""
nome = input('Qual o seu nome? ')
apelido = input('Como você deveria ser reconhecido? ')
print('')
print(f'O {nome} agora será reconhecido pelo apelido {apelido}.\n Seja bem-vindo, Sr.{apelido}!')
print('')
idade = input(f'Sr. {apelido}, qual a sua idade? ')
nascimento = input(f'Em qual ano você nasceu? ')
print('')
print(f'O Sr. {apelido} tem {idade} anos e nasceu em {nascimento}')
print('')
ano_nascimento = 2022 - int(nascimento)
sim_nao = input(f'Voce não teria {ano_nascimento} anos? ')
verdadeiro = input(f'Qual o mês de nascimento? ')
print('')
print(f'O Sr. {apelido}, nasceu em {nascimento}, tem {idade} anos e seu mês de nascimento é {verdadeiro}.\n'
      f'Finalizando assim o seu cadastro no sistema!')
