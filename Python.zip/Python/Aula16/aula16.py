"""
Manipulando Strings
- Índices de uma String
- Partição de Strings (start:end:step)
- Funções built-in len, abs, type, print, etc.
Essas funções podem ser usadas diretamente em cada tipo.

índice encontra-se dentro de colchetes([x])
ex.:
positivos de 0 a 9
negativos de -9 a -1

text = 'DarkSide'
print(text[4]) - retornará 'S' de DarkSide
new_txt = text[4:8] - retornará 'Side' de DarkSide
print(text[:9:2]) - retornará 'DrSd' de Darkside (step)
"""
text = 'DarkSide'
print(text[4])
new_txt = text[4:8]
print(new_txt)
print(text[-9:-4])
print(text[:9:2], len(text[:9:2]))