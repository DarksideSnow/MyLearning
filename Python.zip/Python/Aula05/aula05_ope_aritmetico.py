"""
Operadores Aritméticos

( + ): (símbolo da adição) - concatena uma string
ex.: print('40' + '40') = 4040

( - ): (símbolo da subtração)
ex.:

( * ): (símbolo da multiplicação) - pode ser usado como repetição em uma string
ex.: print('Snow' * 4) = SnowSnowSnowSnow

( / ): (símbolo da divisão)
ex.: print(40 / 4) = 10

( // ): (símbolo da divisão inteira)
ex.: print(40.65 / 4.6) = 8.0

( ** ): (símbolo da exponênciação)
ex.: print(4 ** 2) = 16

( % ): (símbolo de resto da divisão)
ex.: print(40 % 3) = 1

{ () }: altera a precedência do cálculo
ex.: print(print(print(40+4*2), print((40+4)*2))

"""
print('Conteúdo sobre Operador Aritmético:')
print('Atenção: Abrir o arquivo e ler a documentação do código!')
print('Exemplos:')
print('Adição ( + ):', 40 + 40)
print('Concatenação ( + ):', '40' + '40')
print('Subtração ( - ):', 40 - 20)
print('Multiplicação ( * ):', 40 * 40)
print('Repetição ( * ):', 'Snow' * 4)
print('Divisão ( / ):', 40 / 4)
print('Divisão Inteira ( // ):', 40.65 // 4.6)
print('Potenciação ( ** ):', 4 ** 2)
print('Resto da Divisão ( % ):', 40 % 3 )
print('Precedência "()":', print(40+4*2), print((40+4)*2))