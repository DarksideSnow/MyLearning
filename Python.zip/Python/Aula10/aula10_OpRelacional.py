"""
Operadores Relacionais:
São feitos para realizar comparações entre itens
==(igual):
2==2 (pergunta que retorna valor booleano, o sinal '=' afirma o valor)

< / >(menor/maior):
2 < 3 (retorna valor booleano, nesse caso 'true' pois 2 é menor que 3)
3 > 2 (retorna valor booleano, nese caso 'true' pois 3 é maior que 2)

<= / >=(menor e igual/maior e igual):
2 <= 3 (retorna valor booleano 'true' pois 2 é menor que 3 porém não é igual 3)
3 >= 4 (retorna valor booleano 'false' pois 3 não é maior e nem igual ao 4)

!=(diferente):
3 != 4 (retorna valor booleano 'true' pois 3 é diferente de 4)

"""
print('Conteúdo sobre Operador Relacional: \n Atenção: Abrir o arquivo e ler a documentação do código!\n')
nome = input('Digite seu nome: ')
idade = input('Digite sua idade: ')
if int(idade) >= 18:
    print(f'O(A) {nome} tem maioridade.')
else:
    print(f'O(A) {nome} não tem maioridade.')