"""
Documentação e funções Built-in
follow: docs.python.org/

Sempre ficar de olho na documentação dos códigos, novas funções sempre estão sendo disponibilizadas no site citado acima

Exemplo de String Methods:
"""
print('Calculador de soma:')
calc_x = input()
calc_y = input()

if calc_x.isnumeric() and calc_y.isnumeric():
    calc_x = int(calc_x)
    calc_y = int(calc_y)
    print(calc_x + calc_y)
else:
    print('Por favor, digite um número de 0 a 9')