"""
A função len(LEN) serve para extrair a quantidade de caracteres sua entrada possui.
Funciona apenas com string. Bool, Int e Float retornam erro de objeto.
"""
user = input('Usuário: ')
pass_true = 'theACEofDARKSIDE'
char = len(user)
if char < 12:
    print('Usuário incompleto')
    input()
else:
    password = input('Senha: ')

if pass_true == password:
    print('conectado com sucesso!')
else:
    print('usuário e/ou senha incorretos')
input()

